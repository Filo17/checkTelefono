//Ambrogiani Filippo 4i CheckTelefono
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Common;

public static class Telefono
{

    public static string Check(string[] input)
    {
        string parola = "";

        //Questo ciclo si ripete per il numero di stringhe presenti nel vettore input e controlla: 
        //per prima cosa se i primi tre numeri di una stringa sono uguali a +39, in caso controlla anche la lunghezza poi la stampa
        for (int i = 0; i < input.Length; i++)
        {
            string primiTreNumeri = "";
            parola = input[i];
            parola = parola.Replace(" ",""); //rimuovo gli spazi
            while (parola.Length < 10){
                i++;
                parola = input[i];
                parola = parola.Replace(" ","");
            }
           
            for (int j = 0; j < 3; j++) { //inserisce i primi tre numeri di una stringa nella variabile "primiTreNumeri"
             primiTreNumeri += parola[j];
            }
            if (primiTreNumeri == "+39") {
                if (parola.Length == 13){return parola;}
            }
        }

        //questo for guarda se il primo numero è uguale a 3 e se la lunghezza è pari a 10, in caso stampa la stringa
        for (int i = 0; i < input.Length; i++)
        {
            parola = input[i];
            parola = parola.Replace(" ","");
            while (parola.Length < 10){
                i++;
                parola = input[i];
                parola = parola.Replace(" ","");
            } 
            if (parola == "") {break;}
            if (parola[0] == '3') {
             if (parola.Length == 10){return parola;}  
            }
        }

        for (int i = 0; i < input.Length; i++){
            string primiQuattroNumeri = "";
            parola = input[i];
            parola = parola.Replace(" ","");
            while (parola.Length < 10){
                i++;
                parola = input[i];
                parola = parola.Replace(" ","");
            }
            for (int j = 0; j < 4; j++){
             primiQuattroNumeri += parola[j];
            }
            if (primiQuattroNumeri == "0039"){
                if (parola.Length == 14){return parola;}     
            }
        }

        return "";
    }
}